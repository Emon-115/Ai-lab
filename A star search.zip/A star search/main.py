from queue import PriorityQueue


# Directory
nodes = {
    0:'S',
    1:'A',
    2:'B',
    3:'C',
    4:'D'
}

# Adjacent From the graph
adjacent=[
          [-1,1,4,-1,-1],  # S
          [-1,-1,2,5,12],  # A
          [-1,-1,-1,2,-1], # B
          [-1,-1,-1,-1,3], # C
          [-1,-1,-1,-1,-1] # D
]

# Heuristic Values
h = [7,6,2,1,0]

# Final Path
final_path = []

# Class
class node:
  def __init__(self, node_no, pre_node, travel_cost, total_cost):
    self.node_no = node_no
    self.pre_node = pre_node
    self.travel_cost = travel_cost
    self.total_cost = total_cost

  def __lt__(self,other):
    return self.total_cost < other.total_cost


# Priority Queue
add=node(0,None,0,h[0])
minQ=PriorityQueue()
minQ.put(add)

while not minQ.empty():
  # Extract Node
  N = minQ.get()
  len_path = N.node_no

  # if N is the destination
  if len_path == 4:
    final_path.append(len_path)
    j = N.pre_node
    # pre_add = j.node_no

    while j != None:
      pre_add = j.node_no
      final_path.append(pre_add)
      j = j.pre_node
    print('Path:',end=' ')

    print('\n')
    # Backtracking 
    for i in reversed(final_path):
      print(nodes[i],end=' ')

    print('\n')
    print(f'Optimal Cost:{N.total_cost}')
    break
  
  # NObNew 
  for i in range(len_path, len_path+1):
    for f in range(0, len(adjacent)):
      # Check the adjacent value
      if adjacent[i][f]!=-1:
        # Actual_cost and Total_cost
        actual_cost=N.travel_cost+adjacent[i][f] # Actual Cost 
        total_cost=actual_cost+h[f]              # Total Cost 
        NObNew=node(f,N,actual_cost,total_cost) # NobNew and push in the queue 
        minQ.put(NObNew)
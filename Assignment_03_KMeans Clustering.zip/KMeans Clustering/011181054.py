import numpy as np
import math as m
from matplotlib import pyplot as plt


X=np.loadtxt("jain_feats.txt")

centroid_old=np.loadtxt("jain_centers.txt")
centroid_new=np.zeros((2,2))

# # ................................
# #initial Scatter Plot
# x1=X[:,0]
# y1=X[:,1]
#
# oldx=centroid_old[:,0]
# oldy=centroid_old[:,1]
#
# plt.scatter(x1,y1,color='blue',s=5)
# plt.scatter(oldx,oldy,color='orange',s=100,marker='*')
# plt.title('Initial scatter plot')
# plt.show()
# #..................................

for e in range(1000):
   k1 = []
   k2 = []
   label=np.empty(X.shape[0])
   temp = 0
   for i in X:
       dist = np.empty(centroid_old.shape[0])
       temp2 = 0
       for j in centroid_old:
           dist[temp2]=m.sqrt(np.sum(np.square(i-j))) #euclidean distance
           temp2 += 1

       label[temp]=dist.argmin() #Return min value's an index number
       temp += 1

   #Update centroids:
   C=X.tolist()
   t1=[]
   t2=[]
   for i in range(X.shape[0]):
       if(label[i]==0):
           t1.append(C[i])
           k1.append(C[i])
       else:
           t2.append(C[i])
           k2.append(C[i])

   t1=np.array(t1)
   t2=np.array(t2)

   avg1=np.mean(t1,axis=0)
   avg2=np.mean(t2,axis=0)
   centroid_new[0]=avg1
   centroid_new[1]=avg2


#Stop Condition Check
   max = 0
   for i in range(2):
       for j in range(2):
           n1 = centroid_new[i][j]
           n2 = centroid_old[i][j]

           temp = n2-n1

           temp=abs(temp)
           if (temp > max):
               max = temp
   H=1*1E-7
   if(max<H):
       break
   else:
       centroid_old[0]=centroid_new[0]
       centroid_old[1]=centroid_new[1]




#Draw the plot
k1=np.array(k1)
k2=np.array(k2)
k1_x=k1[:,0]
k1_y=k1[:,1]

k2_x=k2[:,0]
k2_y=k2[:,1]

tempx=centroid_old[0][0]
tempy=centroid_old[0][1]

temp2x=centroid_old[1][0]
temp2y=centroid_old[1][1]

plt.scatter(k1_x,k1_y,color='Red',s=5)
plt.scatter(k2_x,k2_y,color='green',s=5)
plt.scatter(tempx,tempy,color='Red',s=400,marker='*')
plt.scatter(temp2x,temp2y,color='green',s=400,marker='*')
plt.title('Final scatter plot')
plt.show()




import numpy as np
import matplotlib.pyplot as plt
import random

class KmeansClustering:

    def __init__(self, num_clusters=1):
        '''Within this constructor declare an instance variable that will store the value of 'num_clusters' argument'''
        self.k = num_clusters

    def read_data(self, file_name):
        self.datapoints = np.genfromtxt(file_name)
        # print(self.datapoints)

    def initial_centers(self):

        initial_center = np.genfromtxt("jain_centers.txt")
        # print(initial_center)
        return initial_center

    def plot_initial_data(self, cluster_centers):

        x = self.datapoints[:, 0]
        y = self.datapoints[:, 1]
        plt.scatter(x, y, s=5, marker="p", label="initial data")
        # cx = cluster_centers[:, 0]
        # cy = cluster_centers[:, 1]
        # plt.scatter(cx, cy, s=100, color="r", marker="p", label="initial centers")
        x = cluster_centers[0, 0]
        y = cluster_centers[0, 1]
        plt.scatter(x, y, s=100, color='r', marker="*", label="initial center")
        x = cluster_centers[1, 0]
        y = cluster_centers[1, 1]
        plt.scatter(x, y, s=100, color='r', marker="*", label="initial center")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.title("Initial data points")
        plt.legend()
        plt.show()

    def decide_cluster(self, point, cluster_centers):
        distancearr = (cluster_centers - point) ** 2
        # print(distancearr.sum(axis = 1))
        # print(distancearr.shape)
        return (np.argmin(distancearr.sum(axis=1)))

    def cluster_formation(self, cluster_centers):

        full_cluster = {0: [], 1: []}  # delclaring the cluster dictionary.

        for eachpoints in self.datapoints:  # access each dataset points
            index = self.decide_cluster(eachpoints,
                                        cluster_centers)  # passing each dataset point to calculate distance from center and the return the desire index
            # print(index)
            full_cluster[index].append(eachpoints)  # append the point into the center(index/key) with min distance
            # print(full_cluster)
        return full_cluster

    def new_center(self, full_cluster):

        # print(full_cluster.items())
        new_centers = np.empty((2, 2), float)

        for eachcenter in range(0, self.k):
            # print("sel.k", self.k)
            # print(eachcenter)
            nparray = np.array(full_cluster[eachcenter])
            mean_value = nparray.mean(axis=0)
            # print(mean_value)
            new_centers[eachcenter:eachcenter + 1, 0:2] = mean_value

        return new_centers

    def switch_counts(self, prevcluster, newcluster):

        count = 0
        for key in range(0, self.k):
            for items in np.array(prevcluster[key]):
                if items in np.array(newcluster[key]):
                    pass
                else:
                    count = count + 1
        # print(count)
        return count

    def kmeans_algo(self):

        initial_center = self.initial_centers()
        self.plot_initial_data(initial_center)
        initial_full_cluster = self.cluster_formation(
            initial_center)  # assigning every datapoint to a spicific center among k no of center.
        # print("initial full cluster: ",initial_full_cluster)
        # print("Number of errors:")
        while True:
            self.new_centers = self.new_center(initial_full_cluster)
            new_full_cluster = self.cluster_formation(self.new_centers)
            compare = self.switch_counts(initial_full_cluster, new_full_cluster)
            if compare < 10:
                break
            initial_full_cluster = new_full_cluster

        return new_full_cluster

    def plot_final_cluster(self, clusters):
        '''Will take input a full cluster dictionary object as input.
        For each cluster draw a different scatter plot and also show the centers of the each cluster'''
        for key in range(0, self.k):
            points_list = clusters[key]
            numpy_list = np.array(points_list)
            cx = numpy_list[:, 0]
            cy = numpy_list[:, 1]
            plt.scatter(cx, cy, s=5, marker="p")
            plt.xlabel("X")
            plt.ylabel("Y")
            plt.title("Final clusters")
        x = self.new_centers[0, 0]
        y = self.new_centers[0, 1]
        plt.scatter(x, y, s=100, color='r', marker="*", label="final center")
        x = self.new_centers[1, 0]
        y = self.new_centers[1, 1]
        plt.scatter(x, y, s=100, color='g', marker="*", label="final center")

        plt.legend()
        plt.show()
# Creating the object and calling necessary methods
obj = KmeansClustering(2)
obj.read_data("jain_feats.txt")  # will read the data from the file and store in a 2D numpy array (for example, datapoints)
final_cluster = obj.kmeans_algo()  # calling the main kmeans clustering algorithm for cluster formation
obj.plot_final_cluster(final_cluster)  # will scatter plot all the clusters with corresponding centers
